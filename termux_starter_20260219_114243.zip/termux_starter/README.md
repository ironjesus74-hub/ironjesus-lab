# termux_starter

## Included scripts
- `storage_report`
- `net_diag`
- `dns_check`
- `http_status`
- `zip_project`
- `checksum_manifest`
- `termux_backup_home`
- `safe_update`

## Install (Termux)
1) Copy scripts into a folder in your PATH (example: $HOME/bin)
2) chmod +x the scripts
3) Run them from terminal

