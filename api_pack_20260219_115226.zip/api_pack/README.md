# api_pack

## Included scripts
- `webhook_send`
- `api_latency`
- `header_test`
- `json_filter`
- `endpoint_monitor`

## Install (Termux)
1) Copy scripts into a folder in your PATH (example: $HOME/bin)
2) chmod +x the scripts
3) Run them from terminal

